var express = require('express');
var app = express();
var bodyParser = require('body-parser');

const apiRouter = require('./routes')

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use('/api', apiRouter);
app.use(function(req, res) {
    res.status(404).send({ url: req.originalUrl + ' not found' })
});



app.listen(3000).on('listening', () => {
    console.log(`🚀 are live on 3000`);
});