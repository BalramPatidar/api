const express = require('express');
const userRoutes = require('./controller/user_management');


const router = express.Router();

router.get('/getUSerData/:users', userRoutes.getUSerData);
router.post('/createUser/:users', userRoutes.createUser);
router.patch('/patchUser/:users', userRoutes.patchUser);
router.delete('/DetaleUser/:users', userRoutes.DetaleUser);

module.exports = router;