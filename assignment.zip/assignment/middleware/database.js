var mysql = require("mysql");
var connection = require("../database");

const query = (quertText, table, params) => {
    var dbQuery = mysql.format(quertText, table);
    return new Promise((resolve, reject) => {
        connection.query(dbQuery, params, function(err, rows) {
            if (err) {
                reject(err);
            } else {
                resolve(rows);
            }
        })
    });
}


module.exports = {
    query
}