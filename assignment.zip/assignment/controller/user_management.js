var conection = require('../middleware/database');

var url = require('url');

async function getUSerData(req, res) {
    try {
        var url_data = url.parse(req.url, true);
        var query_data = url_data.query;
        var message = '';
        if (query_data.id != null && query_data.id != '' && query_data.phoneNumber != '' && query_data.phoneNumber != null) {
            var data = await conection.query('SELECT * FROM user WHERE id = ' + query_data.id + ' AND phoneNumber= ' + query_data.phoneNumber + '');
            if (data.length > 0) {
                message = "User Data";
            } else {
                message = "User Not Found !";
            }
        } else {
            var data = await conection.query('SELECT * FROM user');
            if (data.length > 0) {
                message = "User Data List";
            } else {
                message = "User List Not Found !";
            }
        }

        results = JSON.parse(JSON.stringify(data));
        var response = {
            message: message,
            status: 200,
            data: results,

        }
        res.status(200).json(response);
    } catch (err) {
        res.status(201).json(err);
    }

}

async function createUser(req, res) {
    try {
        const { name, email, phoneNumber } = req.body;

        var data = await conection.query('INSERT INTO user ( name, phoneNumber, email) VALUES ("' + name + '", "' + phoneNumber + '","' + email + '")');

        if (data.insertId != 0) {
            var user_data = await conection.query('SELECT * FROM user WHERE id = ' + data.insertId + '');
            var response = {
                message: 'Create User Successfuly!',
                status: 200,
                data: user_data
            }
            res.status(200).json(response);
        } else {
            var response = {
                message: "Create User Faild!",
                status: 201,
            }
            res.status(201).json(response);
        }

    } catch (err) {
        var response = {
            message: "Error the code",
            status: 201,
            data: err
        }
        res.status(201).json(response);
    }

}





async function patchUser(req, res) {
    try {

        var url_data = url.parse(req.url, true);
        var query_data = url_data.query;
        var id = query_data.id;
        id = id.split(",");
        var phoneNumber = query_data.phoneNumber;
        phoneNumber = phoneNumber.split(",");
        var name = query_data.name;
        name = name.split(",");
        var email = query_data.email;
        email = email.split(",");

        var count = 0;
        var valid_id = [];
        if (id.length === phoneNumber.length && id.length === email.length && id.length === name.length) {

            for (let index = 0; index < id.length; index++) {
                if (id[index] != '' && id[index] != null) {
                    var data = await conection.query('SELECT * FROM user WHERE id = ' + id[index] + '');
                    if (data.length > 0) {
                        valid_id.push(parseInt(id[index]));
                        var patch_user = await conection.query('UPDATE user SET name="' + name[index] + '" ,email="' + email[index] + '" , phoneNumber ="' + phoneNumber[index] + '" WHERE id = ' + id[index] + '');


                        if (patch_user.affectedRows != 0) {
                            count++;
                        }
                    }
                }

            }


            if (count != 0) {
                var result_user = await conection.query('SELECT * FROM user WHERE id IN (' + valid_id + ')');
                var response = {
                    message: 'User Updates  Successfuly!',
                    status: 200,
                    update: count,
                    not_update: id.length - count,
                    data: result_user
                }
                res.status(200).json(response);

            } else {
                var data = await conection.query('SELECT * FROM user');
                var response = {
                    message: "User Not Found !",
                    status: 201,
                    data:data
                }
                res.status(201).json(response);
            }
        } else {


            var response = {
                message: "Please Inter Valid Data !",
                status: 201,
            }
            res.status(201).json(response);

        }




    } catch (err) {
       


        var response = {
            message: "Error the code",
            status: 201,
            data: err
        }
        res.status(201).json(response);
    }

}

async function DetaleUser(req, res) {
    try {
        var url_data = url.parse(req.url, true);
        var query_data = url_data.query;
        var id = query_data.id;
        id = id.split(",");
        var phoneNumber = query_data.phoneNumber;
        phoneNumber = phoneNumber.split(",");
        var count = 0;
        if (id.length === phoneNumber.length) {

            for (let index = 0; index < id.length; index++) {
                const element = id[index];
                const phone = phoneNumber[index];

                var patch_user = await conection.query('DELETE FROM user WHERE id = ' + id[index] + ' AND phoneNumber=' + phoneNumber[index] + '');
                if (patch_user.affectedRows != 0) {
                    count++;
                } else {

                }
            }


            if (count != 0) {
                var response = {
                    message: 'User Delete Successfuly!',
                    status: 200,
                    delete: count,
                    not_delete: id.length - count
                }
                res.status(200).json(response);

            } else {

                var response = {
                    message: "User Not Found !",
                    status: 200,
                }
                res.status(200).json(response);
            }
        } else {


            var response = {
                message: "pleale inter valid data",
                status: 201,
            }
            res.status(201).json(response);

        }



    } catch (err) {

        var response = {
            message: "Error the code",
            status: 201,
            data: err
        }
        res.status(201).json(response);
    }

}


module.exports = { getUSerData, createUser, patchUser, DetaleUser };