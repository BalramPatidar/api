var mysql = require('mysql');

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'UserManagement'
});

connection.connect(function(err, data) {
    if (err) {
        console.log('Not connected  !')
    } else {
        console.log('connected !');

    }
});


module.exports = connection;